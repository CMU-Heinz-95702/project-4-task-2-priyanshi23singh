/**
 * @author Priyanshi Singh
 * psingh3
 */
package com.example.dspicture;

// Importing necessary Android and Java classes.
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/**
 * An activity class that extends AppCompatActivity to provide UI and functionality
 * for searching and displaying picture details.
 */
public class InterestingPicture extends AppCompatActivity {

    /**
     * Called when the activity is starting. This is where most initialization should go:
     * calling setContentView(int) to inflate the activity's UI, using findViewById(int)
     * to programmatically interact with widgets, and setting up listeners.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously
     *                           being shut down then this Bundle contains the most recent
     *                           data, otherwise it is null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the user interface layout for this Activity.
        // The layout file is defined in the project res/layout/activity_main.xml file.
        setContentView(R.layout.activity_main);

        // Initialize the submit button from the layout.
        Button submitButton = findViewById(R.id.submit);
        // Set an OnClickListener to the button to handle user interactions.
        submitButton.setOnClickListener(view -> {
            // When the button is clicked, retrieve the text entered in the EditText by the user.
            String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
            // Create a new instance of GetPicture, passing the current instance and the search term.
            GetPicture gp = new GetPicture(this, searchTerm);
            // Call the search method to execute the search operation.
            gp.search(this);
        });
    }

    /**
     * This method is a callback used by GetPicture to update the UI with the picture and its details.
     * It updates the ImageView and TextViews with the picture, ingredients, and recipe obtained.
     *
     * @param picture The bitmap image to display.
     * @param ingredients The list of ingredients associated with the picture.
     * @param recipe The text description of the recipe.
     */
    public void pictureAndDetailsReady(Bitmap picture, List<String> ingredients, String recipe) {
        // Initialize UI components from the layout.
        ImageView pictureView = findViewById(R.id.interestingPicture);
        TextView ingredientsView = findViewById(R.id.ingredients);
        TextView recipeView = findViewById(R.id.recipe);

        // Check if a valid picture is received.
        if (picture != null) {
            // Set the picture to the ImageView and make it visible.
            pictureView.setImageBitmap(picture);
            pictureView.setVisibility(View.VISIBLE);

            // Build the ingredients text to display.
            StringBuilder ingredientsText = new StringBuilder("Ingredients:\n");
            for (String ingredient : ingredients) {
                ingredientsText.append("- ").append(ingredient).append("\n");
            }
            // Set the built string to the TextView for ingredients.
            ingredientsView.setText(ingredientsText.toString());

            // Set the recipe text to the TextView for the recipe.
            recipeView.setText("Recipe:\n" + recipe);
        } else {
            // If no picture is received, handle this case gracefully.
            pictureView.setVisibility(View.GONE); // Hide the ImageView.
            ingredientsView.setText("No picture available"); // Display a fallback text.
            recipeView.setText("Recipe:\n" + recipe); // Still show the recipe text.
        }
    }
}
