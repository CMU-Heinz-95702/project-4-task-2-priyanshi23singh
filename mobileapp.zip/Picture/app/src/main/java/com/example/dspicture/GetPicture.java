/**
 * @author Priyanshi Singh
 * psingh3
 */
package com.example.dspicture;

// Importing necessary Android, networking, and JSON handling classes.
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * This class handles retrieving a picture and its details based on a search term using an API.
 */
public class GetPicture {
    // Interface reference for callback to the activity when the picture and details are ready.
    private InterestingPicture ip;
    // Search term used for querying the API.
    private String searchTerm;

    /**
     * Constructor to initialize the GetPicture instance.
     *
     * @param ip          The callback interface implementation to notify once data is ready.
     * @param searchTerm  The search term for the picture query.
     */
    public GetPicture(InterestingPicture ip, String searchTerm) {
        this.ip = ip;
        this.searchTerm = searchTerm;
    }

    /**
     * Initiates the search operation in a background thread.
     *
     * @param activity The parent activity that implements the InterestingPicture interface, used to run tasks on the UI thread.
     */
    public void search(Activity activity) {
        new BackgroundTask(activity).execute(searchTerm);
    }

    /**
     * Private inner class extending AsyncTask to perform network operations on a background thread.
     */
    private class BackgroundTask extends AsyncTask<String, Void, Void> {
        // Reference to the activity for UI updates; ensures we can runOnUiThread for thread-safe operations.
        private final Activity activity;

        /**
         * Constructor for the BackgroundTask.
         *
         * @param activity The parent activity used for UI operations.
         */
        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        /**
         * Performs the background operation of fetching picture details using the provided search term.
         *
         * @param strings Search terms received from .execute() call on AsyncTask.
         * @return null since the output is handled via the interface callback.
         */
        @Override
        protected Void doInBackground(String... strings) {
            String searchTerm = strings[0];
            search(searchTerm);
            return null;
        }

        /**
         * Conducts the search by making an HTTP GET request to a specified URL, parses the JSON response,
         * and updates the UI thread with the results.
         *
         * @param searchTerm The search term to query the API.
         */
        private void search(String searchTerm) {
            try {
                URL url = new URL("https://crispy-palm-tree-j9qj5w4qpxvcxv-8080.app.github.dev/submit?mealName=" + searchTerm);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();

                InputStream inputStream = connection.getInputStream();
                String jsonResponse = convertStreamToString(inputStream);
                JSONObject jsonObject = new JSONObject(jsonResponse);

                String imageUrl = jsonObject.getString("picture");
                Bitmap picture = getRemoteImage(new URL(imageUrl));

                String recipe = jsonObject.getString("recipe");
                List<String> ingredients = new ArrayList<>();
                JSONArray ingredientsJsonArray = jsonObject.getJSONArray("ingredients");
                for (int i = 0; i < ingredientsJsonArray.length(); i++) {
                    ingredients.add(ingredientsJsonArray.getString(i));
                }

                // Post results back to the UI thread using the callback interface.
                activity.runOnUiThread(() -> ip.pictureAndDetailsReady(picture, ingredients, recipe));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        /**
         * Retrieves an image from a remote server.
         *
         * @param url The URL to fetch the image from.
         * @return The Bitmap image fetched, or null if an error occurs.
         */
        private Bitmap getRemoteImage(URL url) {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream input = new BufferedInputStream(connection.getInputStream());
                return BitmapFactory.decodeStream(input);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        /**
         * Helper method to convert an InputStream to a String, typically used to convert response streams from HTTP requests.
         *
         * @param is The InputStream to convert.
         * @return A String representation of the InputStream data.
         */
        private String convertStreamToString(InputStream is) {
            Scanner s = new Scanner(is).useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
    }
}
